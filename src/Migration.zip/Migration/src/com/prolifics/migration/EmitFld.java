package com.prolifics.migration;

public class EmitFld implements Comparable<EmitFld> {
	int lineno;
	int column;
	String name;
	int arrsize;
	String widgetType;



	public String getWidgetType() {
		return widgetType;
	}

	public void setWidgetType(String widgetType) {
		this.widgetType = widgetType;
	}

	public EmitFld(int lineno, int column, String name, int arrsz,String wgtType) {
		super();
		this.lineno = lineno;
		this.column = column;
		this.name = name;
		this.arrsize=arrsz;
		this.widgetType=wgtType;
	}

	public int getLineno() {
		return lineno;
	}

	public void setLineno(int lineno) {
		this.lineno = lineno;
	}

	public int getColumn() {
		return column;
	}

	public void setColumn(int column) {
		this.column = column;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public int getArrsize() {
		return arrsize;
	}

	public void setArrsize(int arrsize) {
		this.arrsize = arrsize;
	}
	
	@Override
	public int compareTo(EmitFld arg0) {
		int compareLine = (arg0.getLineno());

		// ascending order
		return this.lineno - compareLine;

		// descending order
		// return compareLine - this.line;
	}
}
