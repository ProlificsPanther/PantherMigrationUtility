package com.prolifics.migration;

import java.util.ArrayList;

public class JamField {
	// This object represents a Jam Field for generation the out put.
	String label;
	String name;
	int linenumber;
	int column;   
	ArrayList<String> jfList = new ArrayList<>();
	
	
	public ArrayList<String> getJfList() {
		return jfList;
	}
	public void setJfList(ArrayList<String> jfList) {
		this.jfList = jfList;
	}
	public String getLabel() {
		return label;
	}
	public void setLabel(String label) {
		this.label = label;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getLinenumber() {
		return linenumber;
	}
	public void setLinenumber(int linenumber) {
		this.linenumber = linenumber;
	}
	public int getColumn() {
		return column;
	}
	public void setColumn(int column) {
		this.column = column;
	}


}
