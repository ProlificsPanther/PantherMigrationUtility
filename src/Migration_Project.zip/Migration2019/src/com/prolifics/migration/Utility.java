package com.prolifics.migration; 

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Properties;



public class Utility { 

	static String utilpath ;
	static String[] categoryArr = { "A:", "B:", "C:", "F:", "G:", "I:", "L:", "R:", "S:", "T:", "Y:","MENU:" };
	static String gflogpath = "//";
	
	public static String getScrnName(String str) {
		
		String[] sArr = str.split("\\.");
		return sArr[0].toString();
	}

	public static boolean setCurrentDirectory(String directory_name) {
		boolean result = false; // Boolean indicating whether directory was set
		File directory; // Desired current working directory

		directory = new File(directory_name).getAbsoluteFile();
		if (directory.exists() || directory.mkdirs()) {
			result = (System.setProperty("user.dir", directory.getAbsolutePath()) != null);
		}

		return result;
	}

	public static boolean myFormlib(File directory, String flag, String libpath, String sScrnName) {
		getProps();
		String exename = utilpath + "/" + "formlib";

		ProcessBuilder processbuilder;
		if (sScrnName.isEmpty()) {
			processbuilder = new ProcessBuilder(exename, flag, libpath);
		} else {
			processbuilder = new ProcessBuilder(exename, flag, libpath, sScrnName);
		}
		processbuilder.directory(directory);
		Process process;
		try {
			process = processbuilder.start();
			try {
				int exitValue = process.waitFor();
				//System.out.println("\n\nExit Value is " + exitValue);
				if (exitValue == 0)
				{
					//System.out.println("Your Screen has been converted successfully.");
					return true;
				}
					
				else
				{
					System.out.println("Something went wrong. Please check if you have entered a valid screen/lib name.");
					return false;
				}

			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return false;
			}
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			System.out.println("Please enter valid util path");
			//e1.printStackTrace();
			return false;
		}
	}

	public static boolean myF2asc(File directory, String flag, String asciiscrnname, String sScrnName) {
		getProps();
		String exename = utilpath + "/" + "f2asc";
		return my2asc(directory,flag,asciiscrnname,sScrnName,exename);
	}

	
	public static ArrayList<String> buildScreenArrayList(ArrayList<String> mylist, String sScrnName) {

		try {
			// first get all screen attributes into screen list
			ArrayList<String> screenList = new ArrayList<>();
			Iterator<String> it = mylist.iterator();
			String search = "S:" + sScrnName;
			boolean bend = false;
			while (it.hasNext()) {
				String line = it.next();
				if (line.startsWith(search)) {
					screenList.add(line);
					it.remove();
					// now read in till next Category change
					while (it.hasNext()) {
						String sline = it.next();

						for (String cat : categoryArr) {
							if (sline.startsWith(cat)) {
								// reached the end
								bend = true;
								break;
							}
						}
						if (bend)
							break;
						it.remove();
						screenList.add(sline);
					}
				}
				// so now just continue
			}
			// now I have the Screen Array loop through this array to find the
			// attribute
			// now lets get rid of all the Screen
			return screenList;

		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			return null;
		}
	}

	public static int checkAttribute(ArrayList<String> myList, String attribute) {

		try {
			int idx = -1;
			// now I have the Screen Array loop through this array to find the
			// attribute
			Iterator<String> sit = myList.iterator();
			while (sit.hasNext()) {
				String line = sit.next();
				idx++;
				if (line.contains(attribute)) {
					return idx;
				}
			}
			return -1;

		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			return -1;
		}
	}

	public static String getAttribute(ArrayList<String> myList, String attribute) {

		try {
			// now I have the Screen Array loop through this array to find the
			// attribute
			Iterator<String> sit = myList.iterator();
			while (sit.hasNext()) {
				String line = sit.next();
				if (line.contains(attribute)) {
					// get the =
					String[] vars = line.split(" ");
					// now we have the name=value
					// find the attribute value
					for (String v : vars) {
						if (v.contains(attribute)) {
							int idx1 = v.indexOf('=')+1;
							return v.substring(idx1);
						} 
					}
				}
			}
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			return "";
		}
		return "";
	}
	
	

	public static String getJamFieldsAttribute(String line, String attrib) {
		if (line.contains(attrib)) {

		}

		return attrib;

	}

	public static boolean buildArrayList(String asciifilename, ArrayList<String> mylist) {
		// open the file read it till we get the S: and then add the Tag then
		// close it
		// FileReader reads text files in the default encoding.

		String line = null;
		try {
			FileReader fileReader = new FileReader(asciifilename);
			// Always wrap FileReader in BufferedReader.
			BufferedReader bufferedReader = new BufferedReader(fileReader);
			mylist.clear();
			String outline = "";
			while ((line = bufferedReader.readLine()) != null) {
				String tline = line.trim();
				if (tline.endsWith("\\")) {
					outline+= tline.substring(0, tline.length() - 1) + " ";
					continue;
				}
				outline+= tline;
				mylist.add(outline);
				outline="";
			}
			bufferedReader.close();
			fileReader.close();
			// now write it back rom memory
		} catch (FileNotFoundException ex) {
			System.out.println("Unable to open file '" + asciifilename + "'");
			return false;
		} catch (IOException ex) {
			System.out.println("Error reading file '" + asciifilename + "'");
			return false;
		}
		return true;
	}
	

	public static boolean writeArrayList(String asciifilename, ArrayList<String> mylist) {
		// open the file read it till we get the S: and then add the Tag then
		// close it
		// FileReader reads text files in the default encoding.

		try {
			// now write it back rom memory
			FileWriter fileWriter = new FileWriter(asciifilename, false);
			BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
			Iterator<String> it = mylist.iterator();
			while (it.hasNext()) {
				String sTmp = it.next();
				bufferedWriter.write(sTmp);
				bufferedWriter.newLine();
			}
			bufferedWriter.flush();
			bufferedWriter.close();
			fileWriter.close();
		} catch (FileNotFoundException ex) {
			System.out.println("Unable to open file '" + asciifilename + "'");
			return false;
		} catch (IOException ex) {
			System.out.println("Error reading file '" + asciifilename + "'");
			return false;
		}
		return true;
	}

	public static ArrayList<String> buildFieldArrayList(ArrayList<String> mylist, String search) {
		// TODO Auto-generated method stub
		try {
			// first get all screen attributes into screen list

			ArrayList<String> ctlList = null;
			Iterator<String> it = mylist.iterator();
			
			while (it.hasNext()) {
				String line = it.next();
				if (line.startsWith(search)) {
					
					// lets get its name
					ctlList = new ArrayList<>();
					ctlList.add(line);
					it.remove();
					// now read in till next Category change
					while (it.hasNext()) {
						String sline = it.next();
						for (String cat : categoryArr) {
							if (sline.startsWith(cat)) {
								// reached the end get out
								return ctlList;
							}
						}
						it.remove();
						ctlList.add(sline);
					}
				}
				// so now just return
			}
			return ctlList;

		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			return null;
		}
	}
	
	public static String getGridName(ArrayList<String> mylist, String search) {
		Iterator<String> it = mylist.iterator();
		
		while (it.hasNext()) {
			String line = it.next();
			if (line.startsWith(search)) {
			String gridName = line.substring(2);
			return gridName ;
			}
			
		}
		return null ;
	}

		
	public static boolean appendOutList(String asciifilename, ArrayList<String> mylist) {
		// open the file read it till we get the S: and then add the Tag then
		// close it
		// FileReader reads text files in the default encoding.

		String line = null;
		try {
			FileReader fileReader = new FileReader(asciifilename);
			// Always wrap FileReader in BufferedReader.
			BufferedReader bufferedReader = new BufferedReader(fileReader);
			String outline = "";
			while ((line = bufferedReader.readLine()) != null) {
/*				if (line.endsWith("\\")) {
				outline += line.substring(0, line.length() - 1);
			} else {*/
				outline += line;
				mylist.add(outline);
				outline = "";
//			}
			}
			bufferedReader.close();
			fileReader.close();
			// now write it back rom memory
		} catch (FileNotFoundException ex) {
			System.out.println("Unable to open file '" + asciifilename + "'");
			return false;
		} catch (IOException ex) {
			System.out.println("Error reading file '" + asciifilename + "'");
			return false;
		}
		return true;
	}
	



public static boolean my2asc(File directory, String flag, String asciiscrnname, String sScrnName, String exename) {

	ProcessBuilder processbuilder;
	if (sScrnName.isEmpty()) {
		processbuilder = new ProcessBuilder(exename, flag, asciiscrnname);
	} else {
		processbuilder = new ProcessBuilder(exename, flag, asciiscrnname, sScrnName);
	}
	processbuilder.directory(directory);
	processbuilder.redirectOutput();

	Process process;
	try {
		process = processbuilder.start();
		try {
			OutputStream stdin = process.getOutputStream();
			InputStream stderr = process.getErrorStream();
			InputStream stdout = process.getInputStream();

			// clean up if any output in stdout
			BufferedReader brCleanUp = new BufferedReader(new InputStreamReader(stdout));
			String line;
			while ((line = brCleanUp.readLine()) != null) {
				System.out.println("[Stdout] " + line);
			}
			brCleanUp.close();
			// clean up if any output in stderr
			brCleanUp = new BufferedReader(new InputStreamReader(stderr));
			while ((line = brCleanUp.readLine()) != null) {
				System.out.println("[Stderr] " + line);
			}
			brCleanUp.close();
			int exitValue = process.waitFor();

			//System.out.println("\n\nExit Value is " + exitValue);
			if (exitValue != 0 ){
				//System.out.println("ERROR converting file back to Binary" );
				System.exit(exitValue);
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	} catch (IOException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
		return false;
	}

	return true;
}

public static String getLeadingBlanks( String str)
{
	String pre="";
	if( str == null)
		return null;
	int len = str.length();
	for( int i=0; i < len; i++)
	{
		if( ! Character.isWhitespace( str.charAt(i)))
			break;
		pre += str.charAt(i);
	}
	return pre;
} 

public static String getTrailingBlanks( String str)
{
	String post="";
	if( str == null)
		return null;
	int len = str.length();
	for( int i=len; i >= 0; i--)
	{
		if( ! Character.isWhitespace( str.charAt( len - 1)))
			break;
		post += str.charAt(i);

  }
  return post;
} 
public static void getProps()
{
	Properties prop = new Properties();

	InputStream input = null;

	try {
		input = new FileInputStream("./config.properties");
	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	// load a properties file
	try {
		prop.load(input);
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	// get the property value and print it out
	utilpath = prop.getProperty("utilpath");

}


}
