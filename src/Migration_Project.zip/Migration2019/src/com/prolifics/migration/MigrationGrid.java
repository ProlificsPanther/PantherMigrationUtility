package com.prolifics.migration;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Properties;
import java.util.Map.Entry;
import java.util.NoSuchElementException;
import java.util.Scanner;
import java.util.Set;

import org.apache.commons.io.FileUtils;

/*
 * This is a migration conversion utility 
 * which converts screen to ascii by f2asc
 * fetches the properties of screen and writes
 * to file
 */
public class MigrationGrid {
	
	static String libbase;
	static String libname;
	static String scrnname;
	static String tgtscreenbase;
	static String asciiscrnname = "";
	static String asciifilename = "";
	static String htmlfilename="";
	static String jsfilename="";
	static String emitfieldfilename="";
	static String htmltemplatepath;
	static String jstemplatepath;	
	
	private static ArrayList<String> list = new ArrayList<>();	
	private static ArrayList<String> ctlList = new ArrayList<>();
	private static ArrayList<String> fldList = new ArrayList<>();
	private static ArrayList<String> outList = new ArrayList<>();
	private static ArrayList<String> lblList = new ArrayList<>();
	private static ArrayList<String> screenList = new ArrayList<>();
	private static HashMap<String,ArrayList<String>> fldMap = new HashMap<>() ;	
	private static HashMap<String,ArrayList<String>> ctlMap = new HashMap<>() ;
	private static HashMap<String,ArrayList<String>> lblMap = new HashMap<>() ;
	private static ArrayList<EmitFld> fldEmitList = new ArrayList<>();
	private static ArrayList<EmitFld> lblEmitList = new ArrayList<>();
	private static ArrayList<EmitFld> hiddenEmitList = new ArrayList<>();
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
						
			Properties prop = new Properties();			
			InputStream input = null;
			
				input = new FileInputStream("./config.properties");
				// load a properties file
				prop.load(input);
				// get the property value and print it out
								
				libbase = prop.getProperty("libbase");
				tgtscreenbase = prop.getProperty("tgtscreenbase");
				htmltemplatepath = prop.getProperty("htmltemplatepath");
				jstemplatepath = prop.getProperty("jstemplatepath");
				
			//first set the base path to the library
			System.out.println("=====================================================");
			System.out.println("Migration.jar - 5.52 Converts Prolifics screens to HTML and JavaScript");
			System.out.println("Copyright  (C) Prolifics,  1985 - 2019");
			System.out.println("=====================================================");	
			System.out.println("Please enter library name(without .lib extension) then press Enter:");
			
			Scanner scanIn = new Scanner(System.in);
			String sLibName = scanIn.nextLine();
			while(sLibName.isEmpty()){
				
				System.out.println("Please enter library name(without .lib extension) then press Enter:");
				System.out.println("or");
				System.out.println("Ctrl+C to exit");
				sLibName = scanIn.nextLine();
			}
						
			String sLibPath = libbase;

			System.out.println("\nEnter the screen name to convert then press Enter:");
			String sScrnName = scanIn.nextLine();
			while (sScrnName.isEmpty())
			{
				System.out.println("\nEnter the screen name to convert then press Enter:");
				System.out.println("or");
				System.out.println("Ctrl+C to exit");
				sScrnName = scanIn.nextLine();
			}
				
			tgtscreenbase = tgtscreenbase+"\\"+sScrnName ;
			asciiscrnname = Utility.getScrnName(sScrnName) + ".txt";
			asciifilename = tgtscreenbase + "\\" + asciiscrnname;
			htmlfilename=Utility.getScrnName(sScrnName) + ".html";
			htmlfilename=tgtscreenbase + "\\" +htmlfilename;
			jsfilename=Utility.getScrnName(sScrnName) + ".js";
			jsfilename=tgtscreenbase + "\\" +jsfilename;
			emitfieldfilename=Utility.getScrnName(sScrnName) + "Emit.txt";
			emitfieldfilename=tgtscreenbase + "\\" +emitfieldfilename;
			// cd to the tgt screen dir to extract them from formlib
			// delete all in dir first
			
			
			File directory = new File(tgtscreenbase).getAbsoluteFile();
			if(directory.exists())
			{
			System.out.println("\nDo you want to overwrite existing files? [yes]/[no]");
			String opt = scanIn.nextLine();
			if(opt.equalsIgnoreCase("yes")){
				
				FileUtils.cleanDirectory(directory);
			}
			else
			{
				System.out.println("Migration exited.");
				return;
			}
			
			}
			Utility.setCurrentDirectory(tgtscreenbase);
			
			String libpath = sLibPath + "/" + sLibName + ".lib";
			// extract screen
			boolean bret = Utility.myFormlib(directory, "-x", libpath, sScrnName);
			if (!bret) {
				return;
			}
			// now continue with creating the ascii screen
			bret = Utility.myF2asc(directory, "-a", asciiscrnname, sScrnName);
			if (!bret) {
				return;
			}

			// now build the array list so lets get the screen ascii in a list array
			Utility.buildArrayList(asciifilename, list);
			Utility.buildScreenArrayList(list,Utility.getScrnName(sScrnName));

			while (true) {
				ctlList=Utility.buildFieldArrayList(list,"C:");
				if (ctlList == null)
					break;
				ctlMap.put(ctlList.get(0).substring(2), ctlList);
			}
			while (true) {
				fldList=Utility.buildFieldArrayList(list,"F:");
				
				if (fldList == null)
					break;
				if (fldList.get(0).substring(2) .length()==0)
				{
					fldMap.put(fldList.get(1).substring(3), fldList);
				}
				else
				{
					fldMap.put(fldList.get(0).substring(2), fldList);
				}					
			}
			while (true) {
				lblList=Utility.buildFieldArrayList(list,"L:");
				
				if (lblList == null)
					break;
				lblMap.put(lblList.get(1).substring(3), lblList);
				
			}
			// now lets get all fields in sync group to help
			// first build up the list from sync
			String commaDelim = "";
			Set<Entry<String, ArrayList<String>>> flds = fldMap.entrySet();
			Iterator<Entry<String, ArrayList<String>>> fit = flds.iterator();
			while (fit.hasNext()) {
				Entry<String, ArrayList<String>> entry = fit.next();
				ArrayList<String> mylist = entry.getValue();
				int iret = Utility.checkAttribute(mylist, "SYNC-GROUP");
				if (iret > -1) {
					commaDelim += entry.getKey() +",";
					// now we want to remove it bret is the index to the array
				}
			}
			/***********************   ADD EXTRA INPUTS HERE ****************/
			String sFieldlist ="";
			
			if(!commaDelim.equals("")){
				
				sFieldlist = commaDelim;
				if (sFieldlist.isEmpty())
					System.exit(0);
				/***********************   END ADD EXTRA INPUTS HERE ****************/
				if(sFieldlist.length()==0)
					return;
				
				
			}
			
			String[] sFldArr = sFieldlist.split(",");
			
			// now set the colors of the fields
			
			Set<Entry<String, ArrayList<String>>> flds1 = fldMap.entrySet();
			Iterator<Entry<String, ArrayList<String>>> fit1 = flds1.iterator();
			while (fit1.hasNext()) {
				Entry<String, ArrayList<String>> entry = fit1.next();
				ArrayList<String> mylist = entry.getValue();
						if(Utility.checkAttribute(mylist, "HIDDEN")==-1)
				{
					String sLine = Utility.getAttribute(mylist, "LINE");
					int iLine = Integer.parseInt(sLine);
					String sColumn = Utility.getAttribute(mylist, "COLUMN");
					int iColumn = Integer.parseInt(sColumn);
					String sName= entry.getKey();
					String sArrSize = Utility.getAttribute(mylist, "ARRAY-SIZE");
					int iArrSize = Integer.parseInt(sArrSize);
					String widgetType = Utility.getAttribute(mylist, "WIDGET-TYPE");
					EmitFld efld = new EmitFld(iLine, iColumn, sName,iArrSize,widgetType);
					fldEmitList.add(efld);
				}
				// added to get hidden fields
				if (Utility.checkAttribute(mylist, "HIDDEN") != -1) {
					String sLine = Utility.getAttribute(mylist, "LINE");
					int iLine = Integer.parseInt(sLine);
					String sColumn = Utility.getAttribute(mylist, "COLUMN");
					int iColumn = Integer.parseInt(sColumn);
					String sName = entry.getKey();
					String sArrSize = Utility.getAttribute(mylist, "ARRAY-SIZE");
					int iArrSize = Integer.parseInt(sArrSize);
					String widgetType = Utility.getAttribute(mylist, "WIDGET-TYPE");

					EmitFld efld = new EmitFld(iLine, iColumn, sName, iArrSize, widgetType);
					hiddenEmitList.add(efld);
				}
				//end
			}
			Set<Entry<String, ArrayList<String>>> lbls = lblMap.entrySet();
			Iterator<Entry<String, ArrayList<String>>> lit = lbls.iterator();
			while (lit.hasNext()) {
				Entry<String, ArrayList<String>> entry = lit.next();
				ArrayList<String> mylist = entry.getValue();
				mylist = Attrib.changeAttribute("B_SCHEME","SCHEME B_SCHEME",mylist);	
				int ind=Utility.checkAttribute(mylist, "TEXT");
				if(ind >-1)
				{
					String s=mylist.get(ind).trim();
					s=s.substring(s.indexOf("=")+1);
					String sLine = Utility.getAttribute(mylist, "LINE");
					int iLine = Integer.parseInt(sLine);
					String sColumn = Utility.getAttribute(mylist, "COLUMN");
					int iColumn = Integer.parseInt(sColumn);
					String widgetType = Utility.getAttribute(mylist, "WIDGET-TYPE");
					EmitFld efld = new EmitFld(iLine, iColumn, s,0,widgetType);
					lblEmitList.add(efld);
				}
			}
			
			// now add the screenList back to list
						Iterator<String> sit = screenList.iterator();
						while (sit.hasNext()) {
							String line = sit.next();
							outList.add(line);
						}
						// now add the ctrlstrings back to list
						Set<Entry<String, ArrayList<String>>> ctls = ctlMap.entrySet();
						Iterator<Entry<String, ArrayList<String>>> cit = ctls.iterator();
						while (cit.hasNext()) {
							Entry<String, ArrayList<String>> entry = cit.next();
							ArrayList<String> mylist = entry.getValue();
							Iterator<String> it2 = mylist.iterator();
							while (it2.hasNext()) {
								String line = it2.next();
								outList.add(line);
							}
						}
						// now dump the rest
						Iterator<String> it = list.iterator();
						while (it.hasNext()) {
							String line = it.next();
							outList.add(line);
						}
						// now add the fieldList back to list
						Set<Entry<String, ArrayList<String>>> outflds = fldMap.entrySet();
						Iterator<Entry<String, ArrayList<String>>> outfit = outflds.iterator();
						while (outfit.hasNext()) {
							Entry<String, ArrayList<String>> entry = outfit.next();
							ArrayList<String> mylist = entry.getValue();
							Iterator<String> it2 = mylist.iterator();
							while (it2.hasNext()) {
								String line = it2.next();
								outList.add(line);
							}
						}
			
			// now add the labels back to list
			Set<Entry<String, ArrayList<String>>> lList = lblMap.entrySet();
			Iterator<Entry<String, ArrayList<String>>> lblit = lList.iterator();
			while (lblit.hasNext()) {
				Entry<String, ArrayList<String>> entry = lblit.next();
				ArrayList<String> mylist = entry.getValue();
				Iterator<String> it2 = mylist.iterator();
				while (it2.hasNext()) {
					String line = it2.next();
					outList.add(line);
				}
			}

			// Now write this to the file
			Utility.writeArrayList(asciifilename, outList);
			try {
				// now write it back rom memory
			
				File htmlTemplateFile=new File(htmltemplatepath);
				String gridName = Utility.getGridName(list, "B:");
				String htmltmp=FileUtils.readFileToString(htmlTemplateFile,(String)null);
				if(gridName!=null)
				{
					htmltmp=htmltmp.replace("$gridName", gridName);	
				}
				htmltmp=htmltmp.replace("$gridName", Utility.getScrnName(sScrnName));
				htmltmp=htmltmp.replace("$jsname", Utility.getScrnName(sScrnName) + ".js");
				String emittmp="";
				if(!fldEmitList.isEmpty())
				{
					Collections.sort(fldEmitList);
					for(EmitFld eField:fldEmitList){
						
						// if array-size is greater than 1 then outpu all emits
						if (eField.getArrsize() > 1) {
							
							emittmp += "<!-- " + eField.getLineno() + "," + "GRID FIELDS OR MULTILINE TEXT" + ","
									+ eField.getColumn() + "-->  <div>{{emit:" + eField.getName() + "}}</div>\n";
						} else {
							emittmp += "<!-- " + eField.getLineno() + "," + eField.getWidgetType() + ","
									+ eField.getColumn() + "-->  <div>{{emit:" + eField.getName() + "}}</div>\n";
						}
					}
				}
				if(!lblEmitList.isEmpty())
				{
					Collections.sort(lblEmitList);
					for(EmitFld lField:lblEmitList){
						
						//emittmp+="<!-- "+ lField.getLineno() +  "," +lField.getColumn() +  "-->  <label for=\"\" class=\"col-sm-4 control-label\">"+lField.getName()+"</label>\n";
						emittmp += "<!-- " + lField.getLineno() + "," + "STATIC LABEL" + ","
								+ lField.getColumn() + "-->  <div>{{emit:" + lField.getName() + "}}</div>\n";
					}
				}
				//added for hidden fields
				if (!hiddenEmitList.isEmpty()) {
					Collections.sort(hiddenEmitList);
					for (EmitFld eField : hiddenEmitList) {
						// if array-size is greater than 1 then outpu all emits
						if (eField.getArrsize() > 1) {
							for (int i = 1; i <= eField.getArrsize(); i++) {
								emittmp += "<!--HIDDEN " + eField.getLineno() + "," + eField.getColumn()
										+ "-->  <div>{{emit:" + eField.getName() + "[[" + i + "]]}}</div>\n";
							}
						} else {
							emittmp += "<!--HIDDEN " + eField.getLineno() + "," + eField.getWidgetType() + ","
									+ eField.getColumn() + "-->  <div>{{emit:" + eField.getName() + "}}</div>\n";
						}
					}

				}
				//end
				
				File jsTemplateFile=new File(jstemplatepath);
				String jstmp=FileUtils.readFileToString(jsTemplateFile,(String)null);
				
				String script="";
				
				
				jstmp=jstmp.replace("$script", script);
				if(gridName!=null){
					jstmp=jstmp.replace("$gridName", gridName);	
				}
				jstmp=jstmp.replace("$gridName", Utility.getScrnName(sScrnName));
				String jsVarDecl="";
				String jsVarAssign="";
				String jsDataAssign="";
				String jsJson="";
				String jsTitle="";
				int count1=2;
				int count2=1;
				int totalCount=sFldArr.length;
				for ( String sfld : sFldArr) {
				jsVarDecl+="var "+sfld+" =\"\";";
				jsVarDecl += "\n\t";
				jsVarAssign+=sfld+" = \"i_\" + i + \"_"+sfld+"\";";
				jsVarAssign += "\n\t\t";
				if(count2==1)
				{
					jsDataAssign+="if (!$('input[name=\"' + "+sfld+" + '\"]').length) {\n";
					jsDataAssign+="\t\t\tbreak;\n";
					jsDataAssign+="\t\t\t}\n";
				}
				jsDataAssign+="\t\t\tvar data"+count2 +"= $('input[name=\"' + "+sfld+" + '\"]').val();";
				jsDataAssign += "\n";
				jsJson+="\""+count1+"\": data"+count2+" , ";
				if(count2==totalCount)			
					jsTitle+="{ \"title\": \""+sfld+"\" }\n\t\t\t";
				else
					jsTitle+="{ \"title\": \""+sfld+"\" },\n\t\t\t";
				count1++;
				count2++;
				}
				jstmp=jstmp.replace("$varDeclar", jsVarDecl);
				jstmp=jstmp.replace("$varAssign", jsVarAssign);
				jstmp=jstmp.replace("$dataAssign", jsDataAssign);
				jstmp=jstmp.replace("$json", jsJson);
				jstmp=jstmp.replace("$colTitle", jsTitle);
				jstmp=jstmp.replace("$fieldName", sFldArr[0]);
				
				File newHtmlFile=new File(htmlfilename);
				FileUtils.writeStringToFile(newHtmlFile, htmltmp,(String)null);
				File newjsFile=new File(jsfilename);
				FileUtils.writeStringToFile(newjsFile, jstmp,(String)null);
				File newEmitFile=new File(emitfieldfilename);
				FileUtils.writeStringToFile(newEmitFile, emittmp,(String)null);
				
			} catch (FileNotFoundException ex) {
				System.out.println("FileNot Found " + ex.getMessage());
				
			} catch (IOException ex) {
				System.out.println("IO exception" + ex.getMessage());
				
			}
			
			System.out.println("=====================================================");
			System.out.println("Web generated files are located in " +tgtscreenbase);
			System.out.println("=====================================================");
			System.out.println("Your screen has been migrated successfully");
			
			scanIn.close();
		}catch (NoSuchElementException e) {
            
			System.out.println("Migration exited.");
         
         } 
		
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
}
}
