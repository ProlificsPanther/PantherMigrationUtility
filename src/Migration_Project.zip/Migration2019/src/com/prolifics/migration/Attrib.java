package com.prolifics.migration;

import java.util.ArrayList;

public class Attrib {
	
	


	public static ArrayList<String> changeAttribute(String attrib,String newValue, ArrayList<String> screenList) {
		try {
			int bret = Utility.checkAttribute(screenList, attrib);
			if (bret > -1) {
				// now we want to remove it bret is the index to the array
				screenList.set(bret,newValue);
				return screenList;
			}
		} catch (Exception ex) {
			System.out.println("Error removing Border ");
			return null;
		}
		return screenList;
	}
	
}
